/**
 * 
 * @param {*} element 需要生成滚动栏的元素
 * @param {*} scrollBox_width 滚动栏宽度(不写默认值为15px)
 */
function myScroll(element, scrollBox_width) {
    // 默认滚动栏宽度为15
    scrollBox_width = scrollBox_width || 15;
    //判断内容盒子定位
    var oldPosition = getComputedStyle(element, null)['position'];
    if (oldPosition == 'static') {
        element.style.position = 'relative';
    }
    //判断内容盒子是否超出部分隐藏
    var oldOverflow = getComputedStyle(element, null)['overflow'];
    if (oldOverflow != 'hidden') {
        element.style.overflow = 'hidden';
    }
    // 内容盒子给滚动栏腾出位置
    element.style.paddingRight = scrollBox_width + 'px';
    var oldWidth = parseInt(getComputedStyle(element, null)['width']);
    element.style.width = oldWidth - scrollBox_width + 'px';
    // 创建滚动盒子(scrollBox)
    var scrollBox = document.createElement('div');
    element.appendChild(scrollBox);
    // 自定义设置样式函数
    function setCSS(ele, obj) {//CSS属性设置，obj内的属性值一定要自带单位
        for (var attr in obj) {
            ele.style[attr] = obj[attr];
        }
    }
    // 初始化scrollBox
    setCSS(scrollBox, {
        height: element.clientHeight + 'px',
        width: scrollBox_width + 'px',
        backgroundColor: 'transparent',
        position: 'absolute',
        right: 0,
        top: 0
    })

    // 创建控制条(bar)放入滚动盒子
    var bar = document.createElement('div');
    scrollBox.appendChild(bar);
    // 初始化bar
    /**
     * bar高度百分比计算
     * 1、盒子可视高度除以盒子滚动总高度*100,得到可视区域占总内容高度的百分比
     * 2、四舍五入取取整
    */
    var bar_height = Math.round((scrollBox.clientHeight / element.scrollHeight) * 100)
    setCSS(bar, {
        height: bar_height + '%',
        width: (scrollBox.offsetWidth - 4) + 'px',
        border: '1px solid ',
        position: 'absolute',
        left: 1 + 'px',
        borderRadius: Math.floor((scrollBox.offsetWidth - 2) / 2) + 'px'
    })
    //创建bar拖拽效果
    bar.onmousedown = function (e) {
        e = e || window.event;
        var mouse_y = e.pageY || e.clientY + document.documentElement.offsetTop;       //鼠标在页面的y坐标
        bar.bar_y = mouse_y - bar.offsetTop; //鼠标在bar内相对坐标
        e.preventDefault();//删除默认事件，不选文字
        setCSS(bar, {
            backgroundColor: '#000',
            boxShadow: '0 0 5px 1px rgba(0,0,0,.5)',
            opacity: 0.3
        })
        /**
         * 注册鼠标移动事件
         * 1、bar跟随鼠标移动
         * 2、bar不能超出scrollBox
        */
        document.onmousemove = mousemoveHandle;
    }

    function mousemoveHandle(e) {
        e = e || window.event;
        var mouse_move_y = e.pageY || e.clientY + document.documentElement.offsetTop;
        //鼠标坐标 - 鼠标相对bar内坐标 = bar相对父元素scrollBox的坐标 -- 绝对定位top
        var bar_follow =  mouse_move_y - bar.bar_y; 
        if (bar_follow < 0) {
            //bar不能超出scrollBox, 即top不能小于0
            bar_follow = 0;
        }
        if (bar_follow > scrollBox.clientHeight - bar.offsetHeight) {
            //bar不能超出scrollBox, 即top不能大于（scrollBox的高度 - bar自身高度）
            bar_follow = scrollBox.clientHeight - bar.offsetHeight;
        }
        bar.style.top = bar_follow + 'px';
        /**
         * 盒子内容根据bar滚动
         * 1、bar在最高点盒子内容scrollTop为0
         * 2、bar在最低点盒子内容scrollTop为最大值
         * 3、bar滚动距离百分比控制盒子内容scrollTop大小
         *      3.1、bar能滚动的总距离 = scrollBox.clientHeight - bar.offsetHeight
         *      3.2、隐藏内容的总高度 = contentBox.scrollHeight - contentBox.clientHeight
         *      3.3、bar滚动距离与能滚动的总距离的比 = bar_follow / (scrollBox.clientHeight - bar.offsetHeight)
         *      3.4、内容滚动的距离 = bar滚动距离与能滚动的总距离的比 * 隐藏内容的总高度
        */
        element.scrollTop = (bar_follow / (scrollBox.clientHeight - bar.offsetHeight)) * (element.scrollHeight - element.clientHeight);
        //滚动栏保持在内容盒子的右部
        scrollBox.style.top = element.scrollTop + 'px';
    }

    document.addEventListener('mouseup', mouseupHandle, false);
    function mouseupHandle() {
        document.onmousemove = null;
        setCSS(bar, {
            backgroundColor: 'transparent',
            boxShadow: ''
        })
        

    }
}